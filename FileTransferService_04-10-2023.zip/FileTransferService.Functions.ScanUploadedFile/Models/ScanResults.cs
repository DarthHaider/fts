namespace FileTransferService.Functions
{
    public class ScanResults 
    {
        public bool isThreat  { get; set; } = false;
        public string threatType  { get; set; } = "";       
    }
}