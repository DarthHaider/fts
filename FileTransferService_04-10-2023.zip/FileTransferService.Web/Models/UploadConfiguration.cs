﻿namespace FileTransferService.Web.Models
{
    public class UploadConfiguration
    {
        public long MaxBufferedFileSize { get; set; }
    }
}
